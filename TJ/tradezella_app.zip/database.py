"""
database.py
-----------

This module encapsulates all interactions with the underlying SQLite
database used to persist trade data. Keeping database logic here makes
it easy to change the storage backend in the future (e.g. switching
to PostgreSQL) without affecting other parts of the application.

Functions and classes defined here provide CRUD operations for Trade
objects.
"""

import sqlite3
from datetime import datetime
from typing import List

from .models import Trade


class TradeJournalDB:
    """A simple SQLite-backed repository for Trade objects."""

    def __init__(self, db_path: str = "tradezella.db") -> None:
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        # enable row factory to return dictionaries
        self.conn.row_factory = sqlite3.Row
        self._initialize_db()

    def _initialize_db(self) -> None:
        """Create the trades table if it doesn't already exist."""
        with self.conn:
            self.conn.execute(
                """
                CREATE TABLE IF NOT EXISTS trades (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    instrument TEXT NOT NULL,
                    date_time TEXT NOT NULL,
                    position TEXT NOT NULL CHECK (position IN ('long', 'short')),
                    entry_price REAL NOT NULL,
                    exit_price REAL NOT NULL,
                    quantity REAL NOT NULL,
                    notes TEXT
                );
                """
            )

    def add_trade(self, trade: Trade) -> None:
        """Insert a new trade into the database."""
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO trades
                (instrument, date_time, position, entry_price, exit_price, quantity, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    trade.instrument,
                    trade.date_time.isoformat(),
                    trade.position.lower(),
                    trade.entry_price,
                    trade.exit_price,
                    trade.quantity,
                    trade.notes,
                ),
            )

    def list_trades(self) -> List[Trade]:
        """Return all trades ordered by date_time."""
        cursor = self.conn.cursor()
        cursor.execute(
            "SELECT * FROM trades ORDER BY date_time"
        )
        rows = cursor.fetchall()
        return [self._row_to_trade(row) for row in rows]

    def trades_between(self, start_date: datetime, end_date: datetime) -> List[Trade]:
        """Return trades within the inclusive date range."""
        cursor = self.conn.cursor()
        cursor.execute(
            """
            SELECT * FROM trades WHERE date_time >= ? AND date_time <= ?
            ORDER BY date_time
            """,
            (start_date.isoformat(), end_date.isoformat()),
        )
        rows = cursor.fetchall()
        return [self._row_to_trade(row) for row in rows]

    def _row_to_trade(self, row: sqlite3.Row) -> Trade:
        """Convert a database row into a Trade instance."""
        return Trade(
            id=row["id"],
            instrument=row["instrument"],
            date_time=datetime.fromisoformat(row["date_time"]),
            position=row["position"],
            entry_price=row["entry_price"],
            exit_price=row["exit_price"],
            quantity=row["quantity"],
            notes=row["notes"] or "",
        )

    def close(self) -> None:
        """Close the underlying database connection."""
        self.conn.close()
