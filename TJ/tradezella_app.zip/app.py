"""
app.py
------

Main entry point for the Flask web application that provides a user
interface for managing trades. The UI allows traders to manually
input trades, view their trade history, compute performance metrics
and export data. The application uses modular components defined
elsewhere in the package (models, database, analytics) to separate
business logic from presentation.

To run the application:
    1. Ensure dependencies are installed (see requirements.txt).
    2. Execute `python app.py` from within the tradezella_app directory.
    3. Navigate to http://localhost:5000 in your web browser.

Note: The Flask development server is intended for local use. For
production deployments consider using a production WSGI server
such as Gunicorn.
"""

import os
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash

from .database import TradeJournalDB
from .models import Trade
from .analytics import compute_metrics


def create_app() -> Flask:
    """Factory function to create and configure the Flask app."""
    app = Flask(__name__)
    # Secret key needed for flash messages; in production set a secure value
    app.config['SECRET_KEY'] = os.environ.get('FLASK_SECRET_KEY', 'replace-this-secret-key')

    # Initialize the database (ensures DB file and table exist)
    db = TradeJournalDB(os.environ.get('TRADEZELLA_DB_PATH', 'tradezella.db'))

    @app.route('/')
    def index():
        """Home page: list all trades and show summary metrics."""
        trades = db.list_trades()
        metrics = compute_metrics(trades)
        return render_template('index.html', trades=trades, metrics=metrics)

    @app.route('/add', methods=['GET', 'POST'])
    def add_trade():
        """Add a new trade via a web form."""
        if request.method == 'POST':
            # Form submission: parse form fields
            instrument = request.form.get('instrument', '').strip()
            date_time_str = request.form.get('date_time', '').strip()
            position = request.form.get('position', '').strip().lower()
            entry_price = request.form.get('entry_price', '').strip()
            exit_price = request.form.get('exit_price', '').strip()
            quantity = request.form.get('quantity', '').strip()
            notes = request.form.get('notes', '').strip()

            # Basic validation
            error = None
            if not instrument:
                error = 'Instrument is required.'
            if not date_time_str:
                error = 'Date and time are required.'
            if position not in {'long', 'short'}:
                error = 'Position must be long or short.'
            try:
                entry_price_val = float(entry_price)
                exit_price_val = float(exit_price)
                quantity_val = float(quantity)
            except ValueError:
                error = 'Entry price, exit price and quantity must be numbers.'
            # Convert date_time
            try:
                # HTML datetime-local input returns string like '2025-08-26T13:30'
                dt = datetime.fromisoformat(date_time_str)
            except ValueError:
                error = 'Invalid date/time format.'

            if error:
                flash(error, 'danger')
            else:
                trade = Trade(
                    id=None,
                    instrument=instrument,
                    date_time=dt,
                    position=position,
                    entry_price=entry_price_val,
                    exit_price=exit_price_val,
                    quantity=quantity_val,
                    notes=notes,
                )
                db.add_trade(trade)
                flash('Trade added successfully.', 'success')
                return redirect(url_for('index'))
        # GET or validation failure: render form
        return render_template('add_trade.html')

    @app.route('/metrics', methods=['GET', 'POST'])
    def metrics():
        """Display metrics for all trades or a filtered date range."""
        trades = db.list_trades()
        metrics = compute_metrics(trades)
        start_date_val = None
        end_date_val = None
        if request.method == 'POST':
            # parse optional start_date and end_date from form
            start_date_str = request.form.get('start_date', '').strip()
            end_date_str = request.form.get('end_date', '').strip()
            try:
                if start_date_str:
                    start_date_val = datetime.fromisoformat(start_date_str)
                if end_date_str:
                    # Include entire end day; for HTML date input we get date only
                    end_date_val = datetime.fromisoformat(end_date_str).replace(hour=23, minute=59, second=59)
            except ValueError:
                flash('Invalid date range provided.', 'danger')
            # Filter trades if both start and end dates specified
            if start_date_val and end_date_val and start_date_val <= end_date_val:
                trades = db.trades_between(start_date_val, end_date_val)
                metrics = compute_metrics(trades)
            elif start_date_val or end_date_val:
                flash('Please provide both start and end dates.', 'warning')
        return render_template('metrics.html', metrics=metrics, start_date=start_date_val, end_date=end_date_val)

    @app.route('/export')
    def export():
        """Export all trades to CSV and return the file for download."""
        import csv
        from io import StringIO
        from flask import Response
        trades = db.list_trades()
        # Create CSV in memory
        si = StringIO()
        writer = csv.writer(si)
        writer.writerow(["ID", "Instrument", "Date Time", "Position", "Entry Price", "Exit Price", "Quantity", "PnL", "Notes"])
        for t in trades:
            writer.writerow([
                t.id,
                t.instrument,
                t.date_time.isoformat(sep=' ', timespec='minutes'),
                t.position,
                t.entry_price,
                t.exit_price,
                t.quantity,
                t.pnl,
                t.notes,
            ])
        csv_data = si.getvalue()
        # Return as a downloadable file
        return Response(
            csv_data,
            mimetype='text/csv',
            headers={
                'Content-Disposition': 'attachment;filename=trades.csv'
            }
        )

    return app


if __name__ == '__main__':
    # When run directly, create the app and start the development server
    app = create_app()
    app.run(debug=True, host='0.0.0.0', port=int(os.environ.get('PORT', 5000)))